import { useState, useEffect, lazy, Suspense } from "react";
import { supabase } from "./api/client";

import Sidebar from "./components/layout/Sidebar";
import Topbar from "./components/layout/Topbar";
import LoginView from "./components/auth/LoginView";
import { useProducts } from "./hooks/useProducts";

// ── Lazy-load each page ──────────────────────────────────────────────────
// Previously every page (Dashboard, Products, POS, Invoices, Reports,
// Customers, Settings, Profile) was bundled together into one huge ~1MB+
// JS file that had to be downloaded, parsed, and executed before the app
// could even show the login screen — and again on every full page reload.
// Splitting each page into its own chunk means only the page you're
// actually looking at gets loaded, which noticeably speeds up first load
// and reduces the "whole app feels slow" effect. Pages are cached by the
// browser after their first visit, so switching back to an already-opened
// page is instant.
const DashboardView = lazy(() => import("./components/dashboard/DashboardView"));
const ProductsView = lazy(() => import("./components/products/ProductsView"));
const POSView = lazy(() => import("./components/pos/POSView"));
const InvoiceView = lazy(() => import("./components/invoices/InvoiceView"));
const ReportsView = lazy(() => import("./components/reports/ReportsView"));
const CustomersView = lazy(() => import("./components/customers/CustomersView"));
const SettingsView = lazy(() => import("./components/settings/SettingsView"));
const UserProfileView = lazy(() => import("./components/profile/UserProfileView"));

function PageLoader() {
  return (
    <div className="flex-1 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

export default function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeNav, setActiveNav] = useState("Dashboard");
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [currentUser, setCurrentUser] = useState(null);
  const [authLoading, setAuthLoading] = useState(true);

  const {
    loading: dataLoading,
    products, alerts, stats, allInvoices,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    posStats, completeSale, recordSale,
    createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer, receivePayment, addBalanceAdjustment,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
    restoreBackup,
  } = useProducts(currentUser?.uid);

  // ── Auth state listener (Supabase) ─────────────────────────────────────────
  // IMPORTANT: Supabase fires onAuthStateChange not just on real sign-in/out —
  // it also fires TOKEN_REFRESHED (silent background token renewal, every
  // ~hour) and INITIAL_SESSION/re-validation whenever the browser tab regains
  // focus. The old code called setActiveNav("Dashboard") + created a brand
  // new currentUser object on every single one of those events. That meant:
  //   1) The user got silently yanked back to Dashboard mid-work at random
  //      times (e.g. every time they switched back to the browser tab) —
  //      and Dashboard is the heaviest page to compute, so this is exactly
  //      what showed up as a random "hang" anywhere in the app.
  //   2) A brand-new currentUser object reference on every event forced
  //      extra re-renders through the whole app tree even when nothing
  //      about the user had actually changed.
  // Fix: only reset navigation on a genuine fresh sign-in, and only update
  // currentUser state when the uid actually changed.
  useEffect(() => {
    let previousUid = null;

    const buildUser = (session) => ({
      name: session.user.user_metadata?.full_name || session.user.email?.split("@")[0] || "User",
      email: session.user.email,
      uid: session.user.id,
      photoURL: session.user.user_metadata?.avatar_url || null,
    });

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        previousUid = session.user.id;
        setCurrentUser(buildUser(session));
        setActiveNav("Dashboard");
      }
      setAuthLoading(false);
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session?.user) {
        const isNewLogin = previousUid !== session.user.id;
        previousUid = session.user.id;

        // Avoid recreating the object (and re-rendering the whole app) when
        // nothing actually changed, e.g. on a silent TOKEN_REFRESHED event.
        setCurrentUser((prev) => (prev && prev.uid === session.user.id ? prev : buildUser(session)));

        // Only jump to Dashboard on a genuine new sign-in — never on
        // background session/token refresh events.
        if (event === "SIGNED_IN" && isNewLogin) {
          setActiveNav("Dashboard");
        }
      } else {
        previousUid = null;
        setCurrentUser(null);
      }
      setAuthLoading(false);
    });

    return () => subscription.unsubscribe();
  }, []);

  // ── Auth handlers ───────────────────────────────────────────────────────
  const handleEmailLogin = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  };

  const handleEmailRegister = async (email, password, name) => {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { data: { full_name: name } },
    });
    if (error) throw error;
  };

  const handleGoogleLogin = async () => {
    const { error } = await supabase.auth.signInWithOAuth({
      provider: "google",
      options: { redirectTo: window.location.origin },
    });
    if (error) throw error;
  };

  const handleForgotPassword = async (email) => {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) throw error;
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    setActiveNav("Dashboard");
  };

  const handleUpdatePassword = async (_currentPassword, newPassword) => {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) throw error;
  };

  // ── Loading screen ──────────────────────────────────────────────────────
  if (authLoading || (currentUser && dataLoading)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-700 flex items-center justify-center shadow-lg shadow-blue-200">
            <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
            </svg>
          </div>
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          {currentUser && <p className="text-sm text-slate-500">Loading your data...</p>}
        </div>
      </div>
    );
  }

  // ── Login screen ────────────────────────────────────────────────────────
  if (!currentUser) {
    return (
      <LoginView
        onEmailLogin={handleEmailLogin}
        onEmailRegister={handleEmailRegister}
        onGoogleLogin={handleGoogleLogin}
        onForgotPassword={handleForgotPassword}
      />
    );
  }

  const pageConfig = {
    Dashboard: { title: "Dashboard", subtitle: `Welcome back, ${currentUser.name} 👋` },
    Products: { title: "Products", subtitle: "Manage inventory & stock alerts" },
    "Point of Sale": { title: "Point of Sale", subtitle: "Sell products & process orders" },
    Invoices: { title: "Invoices", subtitle: "Invoice banayein aur manage karein" },
    Reports: { title: "Reports", subtitle: "Sales aur revenue ki detailed reports" },
    Customers: { title: "Customers", subtitle: "Manage your customer directory" },
    Settings: { title: "Settings", subtitle: "Customize categories and app settings" },
    Profile: { title: "My Profile", subtitle: "Manage your account and preferences" },
  };
  const config = pageConfig[activeNav] || pageConfig.Dashboard;

  return (
    <div className="flex h-screen bg-slate-50 font-sans overflow-hidden">
      <Sidebar
        sidebarOpen={sidebarOpen}
        mobileSidebar={mobileSidebar}
        setMobileSidebar={setMobileSidebar}
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        setSidebarOpen={setSidebarOpen}
        appSettings={appSettings}
      />
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Topbar
          title={config.title}
          subtitle={config.subtitle}
          onMenuClick={() => setMobileSidebar(true)}
          alerts={alerts}
          currentUser={currentUser}
          onLogout={handleLogout}
          setActiveNav={setActiveNav}
          products={products}
          customers={customers}
          allInvoices={allInvoices}
        />
        {activeNav === "Products" ? (
          <Suspense fallback={<PageLoader />}>
            <ProductsView
              products={products} stats={stats}
              addProduct={addProduct} updateProduct={updateProduct}
              deleteProduct={deleteProduct} stockIn={stockIn} stockOut={stockOut}
              categories={categories}
            />
          </Suspense>
        ) : activeNav === "Point of Sale" ? (
          <Suspense fallback={<PageLoader />}>
            <POSView
              products={products} posStats={posStats}
              completeSale={completeSale} recordSale={recordSale}
              customers={customers}
              categories={categories}
              invoices={allInvoices}
            />
          </Suspense>
        ) : activeNav === "Invoices" ? (
          <Suspense fallback={<PageLoader />}>
            <InvoiceView
              products={products}
              invoices={allInvoices}
              onCreateInvoice={createManualInvoice}
              onUpdateInvoice={updateInvoice}
              onDeleteInvoice={deleteInvoice}
              onReduceStock={completeSale}
              customers={customers}
              invoiceSettings={invoiceSettings}
            />
          </Suspense>
        ) : activeNav === "Reports" ? (
          <Suspense fallback={<PageLoader />}>
            <ReportsView invoices={allInvoices} products={products} invoiceSettings={invoiceSettings} customers={customers} />
          </Suspense>
        ) : activeNav === "Customers" ? (
          <Suspense fallback={<PageLoader />}>
            <CustomersView customers={customers} addCustomer={addCustomer} updateCustomer={updateCustomer} deleteCustomer={deleteCustomer} allInvoices={allInvoices} onReceivePayment={receivePayment} onCreateInvoice={createManualInvoice} onReduceStock={completeSale} onUpdateInvoice={updateInvoice} onDeleteInvoice={deleteInvoice} invoiceSettings={invoiceSettings} products={products} />
          </Suspense>
        ) : activeNav === "Settings" ? (
          <Suspense fallback={<PageLoader />}>
            <SettingsView categories={categories} addCategory={addCategory} removeCategory={removeCategory} appSettings={appSettings} updateAppSettings={updateAppSettings} invoiceSettings={invoiceSettings} updateInvoiceSettings={updateInvoiceSettings} allInvoices={allInvoices} products={products} customers={customers} onRestoreBackup={restoreBackup} />
          </Suspense>
        ) : activeNav === "Profile" ? (
          <Suspense fallback={<PageLoader />}>
            <UserProfileView
              appSettings={appSettings}
              currentUser={currentUser}
              onLogout={handleLogout}
              products={products}
              allInvoices={allInvoices}
              onUpdatePassword={handleUpdatePassword}
            />
          </Suspense>
        ) : (
          <Suspense fallback={<PageLoader />}>
            <DashboardView products={products} allInvoices={allInvoices} customers={customers} />
          </Suspense>
        )}
      </main>
    </div>
  );
}

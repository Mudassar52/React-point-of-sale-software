import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
  collection, doc, getDoc, setDoc, addDoc, updateDoc, deleteDoc,
  onSnapshot, query, orderBy
} from "firebase/firestore";
import { PRODUCT_CATEGORIES } from "../data/mockData";
import { buildStockAlerts, getStockStatus } from "../utils/productHelpers";

// ── IndexedDB helpers for logo (same as SettingsView) ────────────────────────
function openLogoIDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("inv_settings", 1);
    r.onupgradeneeded = (e) => e.target.result.createObjectStore("logo");
    r.onsuccess = (e) => res(e.target.result);
    r.onerror = () => rej(r.error);
  });
}
async function loadLogoFromIDB() {
  try {
    const db = await openLogoIDB();
    return new Promise((res) => {
      const req = db.transaction("logo", "readonly").objectStore("logo").get("current");
      req.onsuccess = () => res(req.result || null);
      req.onerror = () => res(null);
    });
  } catch { return null; }
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useProducts(db, uid) {
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [manualInvoices, setManualInvoices] = useState([]);
  const [categories, setCategories] = useState(PRODUCT_CATEGORIES);
  const [appSettings, setAppSettings] = useState({ appName: "InvManager", tagline: "Pro Dashboard" });
  const [invoiceSettings, setInvoiceSettings] = useState({ ownerName: "", businessName: "", phone: "", address: "", logo: "" });
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const invoiceCounterRef = useRef(0);

  // ── Firestore paths (per-user) ──────────────────────────────────────────
  const paths = useMemo(() => {
    if (!db || !uid) return null;
    const base = `users/${uid}`;
    return {
      products: collection(db, `${base}/products`),
      sales: collection(db, `${base}/sales`),
      manualInvoices: collection(db, `${base}/manualInvoices`),
      customers: collection(db, `${base}/customers`),
      settingsDoc: doc(db, `${base}/config/settings`),
    };
  }, [db, uid]);

  // ── Bootstrap: seed initial data on first login ─────────────────────────
  useEffect(() => {
    if (!db || !uid || !paths) return;

    async function bootstrap() {
      const settSnap = await getDoc(paths.settingsDoc);
      if (!settSnap.exists()) {
        await setDoc(paths.settingsDoc, {
          appSettings: { appName: "InvManager", tagline: "Pro Dashboard" },
          invoiceSettings: { ownerName: "", businessName: "", phone: "", address: "", logo: "" },
          categories: PRODUCT_CATEGORIES,
          invoiceCounter: 0,
        });
        invoiceCounterRef.current = 0;
      } else {
        invoiceCounterRef.current = settSnap.data().invoiceCounter || 0;
      }
      setLoading(false);
    }

    bootstrap();
  }, [db, uid, paths]);

  // ── Real-time listeners ─────────────────────────────────────────────────
  useEffect(() => {
    if (!paths) return;
    const unsubs = [];

    unsubs.push(
      onSnapshot(paths.products, (snap) => {
        setProducts(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(query(paths.sales, orderBy("createdAt", "desc")), (snap) => {
        setSales(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(query(paths.manualInvoices, orderBy("createdAt", "desc")), (snap) => {
        setManualInvoices(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(paths.customers, (snap) => {
        setCustomers(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    // Settings listener
    unsubs.push(
      onSnapshot(paths.settingsDoc, (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (data.appSettings) setAppSettings(data.appSettings);
          if (data.invoiceSettings) {
            const settings = data.invoiceSettings;
            // Logo is stored in IndexedDB (too large for Firestore), resolve it
            if (settings.logo === "__local__") {
              loadLogoFromIDB().then((logoData) => {
                setInvoiceSettings({ ...settings, logo: logoData || "" });
              });
            } else {
              setInvoiceSettings(settings);
            }
          }
          if (data.categories) setCategories(data.categories);
        }
      })
    );

    return () => unsubs.forEach((u) => u());
  }, [paths]);

  // ── Computed ────────────────────────────────────────────────────────────
  const alerts = useMemo(() => buildStockAlerts(products), [products]);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, p) => sum + (p.currentStock || 0), 0);
    const lowStockCount = products.filter((p) => getStockStatus(p) === "low").length;
    const outOfStockCount = products.filter((p) => getStockStatus(p) === "out").length;
    return { totalProducts, totalStock, lowStockCount, outOfStockCount };
  }, [products]);

  const allInvoices = useMemo(() => {
    const normalize = (inv) => {
      // payments array mein advance at sale already hota hai (note: "Advance at sale")
      // sirf extra payments count karo jo advance ke ilawa hain
      const advancePayments = (inv.payments || []).filter(p => p.note && p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
      const extraPayments = (inv.payments || []).filter(p => !p.note || !p.note.includes("Advance at sale")).reduce((s, p) => s + (p.amount || 0), 0);
      // advance field aur advance payments ek hi cheez hain — sirf ek count karo
      const totalPaid = advancePayments + extraPayments + (inv.advance && advancePayments === 0 ? inv.advance : 0);
      const due = Math.max(0, (inv.total || 0) - totalPaid);
      let paymentStatus;
      if (due <= 0) paymentStatus = "paid";
      else if (totalPaid > 0) paymentStatus = "partial";
      else paymentStatus = "udaar";
      return { ...inv, paymentStatus };
    };
    const combined = [
      ...sales.map((s) => normalize({ ...s, source: s.source || "pos" })),
      ...manualInvoices.map((m) => normalize({ ...m, source: m.source || "manual" })),
    ];
    return combined.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [sales, manualInvoices]);

  const posStats = useMemo(() => {
    const inStock = products.filter((p) => p.currentStock > 0).length;
    const today = new Date().toDateString();
    const todaySales = sales.filter((s) => new Date(s.createdAt).toDateString() === today);
    const todayRevenue = todaySales.reduce((sum, s) => sum + (s.total || 0), 0);
    return { inStock, todaySalesCount: todaySales.length, todayRevenue };
  }, [products, sales]);

  // ── Product actions ─────────────────────────────────────────────────────
  const addProduct = useCallback(async (form) => {
    if (!paths) return;
    const product = {
      name: form.name.trim(),
      category: form.category,
      salePrice: Number(form.salePrice),
      stockPrice: Number(form.costPrice),
      costPrice: Number(form.costPrice),
      lowStockAlertQty: Number(form.lowStockAlertQty),
      currentStock: Number(form.currentStock) || 0,
      ctn: Number(form.ctn) || 0,
    };
    const ref = await addDoc(paths.products, product);
    return { ...product, id: ref.id };
  }, [paths]);

  const updateProduct = useCallback(async (id, form) => {
    if (!paths) return;
    const ref = doc(paths.products, String(id));
    await updateDoc(ref, {
      name: form.name.trim(),
      category: form.category,
      salePrice: Number(form.salePrice),
      stockPrice: Number(form.costPrice),
      costPrice: Number(form.costPrice),
      lowStockAlertQty: Number(form.lowStockAlertQty),
      currentStock: Number(form.currentStock) || 0,
      ctn: Number(form.ctn) || 0,
    });
  }, [paths]);

  const deleteProduct = useCallback(async (id) => {
    if (!paths) return;
    await deleteDoc(doc(paths.products, String(id)));
  }, [paths]);

  const stockIn = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0 || !paths) return false;
    const product = products.find((p) => String(p.id) === String(id) || p.id === id);
    if (!product) return false;
    await updateDoc(doc(paths.products, String(id)), {
      currentStock: (product.currentStock || 0) + amount,
    });
    return true;
  }, [paths, products]);

  const stockOut = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0 || !paths) return false;
    const product = products.find((p) => String(p.id) === String(id) || p.id === id);
    if (!product || product.currentStock < amount) return false;
    await updateDoc(doc(paths.products, String(id)), {
      currentStock: product.currentStock - amount,
    });
    return true;
  }, [paths, products]);

  const completeSale = useCallback(async (items) => {
    if (!items?.length || !paths) return { success: false };
    // Validate stock first
    for (const { productId, qty } of items) {
      const p = products.find((x) => String(x.id) === String(productId));
      if (!p || (p.currentStock || 0) < qty) return { success: false };
    }
    // Deduct stock in parallel — much faster than sequential awaits
    await Promise.all(items.map(({ productId, qty }) => {
      const p = products.find((x) => String(x.id) === String(productId));
      if (!p) return Promise.resolve();
      return updateDoc(doc(paths.products, String(productId)), {
        currentStock: (p.currentStock || 0) - qty,
      });
    }));
    return { success: true };
  }, [paths, products]);

  const recordSale = useCallback(async (sale) => {
    if (!paths) return;
    // Assign next invoice number from in-memory counter (no Firestore read needed)
    invoiceCounterRef.current += 1;
    const counter = invoiceCounterRef.current;
    setDoc(paths.settingsDoc, { invoiceCounter: counter }, { merge: true }); // fire & forget
    const paymentStatus = sale.paymentMode === "udaar"
      ? (Number(sale.advance) > 0 ? "partial" : "udaar")
      : "paid";
    const payments = (sale.paymentMode === "udaar" && Number(sale.advance) > 0)
      ? [{ amount: Number(sale.advance), date: new Date().toISOString(), note: "Advance at sale" }]
      : [];
    const record = {
      ...sale,
      source: "pos",
      invoiceNumber: counter,
      createdAt: sale.createdAt || new Date().toISOString(),
      paymentStatus,
      payments,
    };
    const ref = await addDoc(paths.sales, record);
    // Update customer stats if a known customer is linked
    if (sale.customerId) {
      const cust = customers.find((c) => String(c.id) === String(sale.customerId));
      if (cust) {
        await updateDoc(doc(paths.customers, String(sale.customerId)), {
          totalOrders: (cust.totalOrders || 0) + 1,
          totalSpent: (cust.totalSpent || 0) + (sale.total || 0),
          lastOrder: new Date().toISOString(),
        });
      }
    }
    return { ...record, id: ref.id };
  }, [paths, customers]);

  // ── Invoice actions ─────────────────────────────────────────────────────
  const createManualInvoice = useCallback(async (data) => {
    if (!paths) return;
    // Assign next invoice number from in-memory counter (no Firestore read needed)
    invoiceCounterRef.current += 1;
    const counter = invoiceCounterRef.current;
    setDoc(paths.settingsDoc, { invoiceCounter: counter }, { merge: true }); // fire & forget
    const manualPaymentStatus = data.paymentMode === "udaar"
      ? (Number(data.advance) > 0 ? "partial" : "udaar")
      : "paid";
    const manualPayments = (data.paymentMode === "udaar" && Number(data.advance) > 0)
      ? [{ amount: Number(data.advance), date: new Date().toISOString(), note: "Advance at sale" }]
      : [];
    const record = {
      ...data,
      source: "manual",
      invoiceNumber: counter,
      createdAt: data.createdAt || new Date().toISOString(),
      paymentStatus: manualPaymentStatus,
      payments: manualPayments,
    };
    const ref = await addDoc(paths.manualInvoices, record);
    // Update customer stats if a known customer is linked
    if (data.customerId) {
      const cust = customers.find((c) => String(c.id) === String(data.customerId));
      if (cust) {
        await updateDoc(doc(paths.customers, String(data.customerId)), {
          totalOrders: (cust.totalOrders || 0) + 1,
          totalSpent: (cust.totalSpent || 0) + (data.total || 0),
          lastOrder: new Date().toISOString(),
        });
      }
    }
    return { ...record, id: ref.id };
  }, [paths, customers]);

  const updateInvoice = useCallback(async (id, data, source) => {
    if (!paths) return;
    const colRef = source === "manual" ? paths.manualInvoices : paths.sales;
    await updateDoc(doc(colRef, String(id)), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  }, [paths]);

  const deleteInvoice = useCallback(async (id, source) => {
    if (!paths) return;
    const colRef = source === "manual" ? paths.manualInvoices : paths.sales;
    const list = source === "manual" ? manualInvoices : sales;
    const inv = list.find((i) => String(i.id) === String(id));
    await deleteDoc(doc(colRef, String(id)));

    // Restore stock for any items that were taken from inventory (had a
    // productId) when this invoice was created — deleting an invoice should
    // give that stock back, since the sale is being undone.
    if (inv?.items?.length) {
      await Promise.all(inv.items.filter((i) => i.productId).map((i) => {
        const p = products.find((x) => String(x.id) === String(i.productId));
        if (!p) return Promise.resolve();
        return updateDoc(doc(paths.products, String(i.productId)), {
          currentStock: (p.currentStock || 0) + (Number(i.qty) || 0),
        });
      }));
    }

    // Reverse the customer stats that were added when this invoice was created,
    // so a deleted invoice no longer counts towards Orders / Total Spent.
    if (inv?.customerId) {
      const cust = customers.find((c) => String(c.id) === String(inv.customerId));
      if (cust) {
        await updateDoc(doc(paths.customers, String(inv.customerId)), {
          totalOrders: Math.max(0, (cust.totalOrders || 0) - 1),
          totalSpent: Math.max(0, (cust.totalSpent || 0) - (inv.total || 0)),
        });
      }
    }
  }, [paths, sales, manualInvoices, customers, products]);

  // ── Customer actions ────────────────────────────────────────────────────
  const addCustomer = useCallback(async (form) => {
    if (!paths) return;
    const record = {
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email || "",
      city: form.city || "",
      totalOrders: 0,
      totalSpent: 0,
      lastOrder: new Date().toISOString(),
    };
    const ref = await addDoc(paths.customers, record);
    return { ...record, id: ref.id };
  }, [paths]);

  const updateCustomer = useCallback(async (id, form) => {
    if (!paths) return;
    await updateDoc(doc(paths.customers, String(id)), {
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email || "",
      city: form.city || "",
    });
  }, [paths]);

  const deleteCustomer = useCallback(async (id) => {
    if (!paths) return;
    await deleteDoc(doc(paths.customers, String(id)));
  }, [paths]);

  // ── Payment & Ledger actions ────────────────────────────────────────────
  const receivePayment = useCallback(async ({ customerId, amount, date, note, allocations }) => {
    if (!paths) return;
    for (const { invoiceId, amount: payAmt } of allocations) {
      if (!payAmt || payAmt <= 0) continue;
      // Skip virtual "bulk" placeholder — allocations already split by FIFO
      if (invoiceId === "bulk") continue;
      const saleInv = sales.find((s) => String(s.id) === String(invoiceId));
      const manualInv = manualInvoices.find((m) => String(m.id) === String(invoiceId));
      const inv = saleInv || manualInv;
      if (!inv) continue;
      const colRef = manualInv ? paths.manualInvoices : paths.sales;
      const existing = inv.payments || [];
      const newPayments = [...existing, { amount: payAmt, date, note: note || "" }];
      // advance field aur "Advance at sale" payments double count na ho
      const advInPayments = newPayments.filter(p => p.note && p.note.includes("Advance at sale")).reduce((s, p) => s + p.amount, 0);
      const otherPmts = newPayments.filter(p => !p.note || !p.note.includes("Advance at sale")).reduce((s, p) => s + p.amount, 0);
      const standAloneAdv = advInPayments > 0 ? 0 : (inv.advance || 0);
      const totalPaidAmt = advInPayments + otherPmts + standAloneAdv;
      const newStatus = totalPaidAmt >= (inv.total || 0) ? "paid" : totalPaidAmt > 0 ? "partial" : "udaar";
      await updateDoc(doc(colRef, String(invoiceId)), {
        payments: newPayments,
        paymentStatus: newStatus,
        updatedAt: new Date().toISOString(),
      });
    }
  }, [paths, sales, manualInvoices]);

  const addBalanceAdjustment = useCallback(async ({ customerId, type, amount, reason, date }) => {
    if (!paths) return;
    const cust = customers.find((c) => String(c.id) === String(customerId));
    if (!cust) return;
    const existing = cust.adjustments || [];
    const newAdj = [...existing, { type, amount, reason, date }];
    await updateDoc(doc(paths.customers, String(customerId)), {
      adjustments: newAdj,
    });
  }, [paths, customers]);

  // ── Settings actions ────────────────────────────────────────────────────
  const addCategory = useCallback(async (name) => {
    const trimmed = name.trim();
    if (!trimmed || !paths) return;
    if (categories.includes(trimmed)) return;
    const next = [...categories, trimmed];
    await setDoc(paths.settingsDoc, { categories: next }, { merge: true });
  }, [paths, categories]);

  const removeCategory = useCallback(async (name) => {
    if (!paths) return;
    const next = categories.filter((c) => c !== name);
    await setDoc(paths.settingsDoc, { categories: next }, { merge: true });
  }, [paths, categories]);

  const updateAppSettings = useCallback(async (settings) => {
    if (!paths) return;
    const next = { ...appSettings, ...settings };
    await setDoc(paths.settingsDoc, { appSettings: next }, { merge: true });
  }, [paths, appSettings]);

  const updateInvoiceSettings = useCallback(async (settings) => {
    if (!paths) return;
    const next = { ...invoiceSettings, ...settings };
    await setDoc(paths.settingsDoc, { invoiceSettings: next }, { merge: true });
  }, [paths, invoiceSettings]);

  // ── Backup Restore ──────────────────────────────────────────────────────
  const restoreBackup = useCallback(async (data) => {
    if (!paths || !db || !uid) throw new Error("Not logged in");
    const { addDoc: firestoreAddDoc, setDoc: firestoreSetDoc, doc: firestoreDoc, collection: firestoreCollection, deleteDoc: firestoreDeleteDoc, getDocs } = await import("firebase/firestore");

    const base = `users/${uid}`;
    const prodCol = firestoreCollection(db, `${base}/products`);
    const custCol = firestoreCollection(db, `${base}/customers`);
    const salesCol = firestoreCollection(db, `${base}/sales`);
    const manualCol = firestoreCollection(db, `${base}/manualInvoices`);

    // Helper: delete all docs in a collection
    const clearCollection = async (col) => {
      const snap = await getDocs(col);
      await Promise.all(snap.docs.map(d => firestoreDeleteDoc(firestoreDoc(col, d.id))));
    };

    // Clear existing data
    await Promise.all([
      clearCollection(prodCol),
      clearCollection(custCol),
      clearCollection(salesCol),
      clearCollection(manualCol),
    ]);

    // Restore products — original IDs preserve karo
    if (data.products?.length) {
      await Promise.all(data.products.map(p => {
        const { id, ...rest } = p;
        if (id) {
          return firestoreSetDoc(firestoreDoc(prodCol, String(id)), rest);
        }
        return firestoreAddDoc(prodCol, rest);
      }));
    }

    // Restore customers — original IDs preserve karo taake invoices ka customerId match rahe
    if (data.customers?.length) {
      await Promise.all(data.customers.map(c => {
        const { id, ...rest } = c;
        if (id) {
          // setDoc with original ID taake invoice->customer link tuta na rahe
          return firestoreSetDoc(firestoreDoc(custCol, String(id)), rest);
        }
        return firestoreAddDoc(custCol, rest);
      }));
    }

    // Restore invoices — split by source
    const posInvoices = (data.allInvoices || []).filter(inv => inv.source === "pos" || !inv.source);
    const manualInvoices_ = (data.allInvoices || []).filter(inv => inv.source === "manual");

    if (posInvoices.length) {
      await Promise.all(posInvoices.map(inv => {
        const { id, ...rest } = inv;
        return firestoreAddDoc(salesCol, rest);
      }));
    }
    if (manualInvoices_.length) {
      await Promise.all(manualInvoices_.map(inv => {
        const { id, ...rest } = inv;
        return firestoreAddDoc(manualCol, rest);
      }));
    }

    // Restore settings
    if (data.settings) {
      const settingsToSave = {
        appSettings: data.settings.appSettings || appSettings,
        invoiceSettings: { ...(data.settings.invoiceSettings || {}), logo: "" }, // logo IDB mein hai
        categories: data.settings.categories || categories,
      };
      // Logo restore karo IndexedDB mein
      if (data.settings.invoiceSettings?.logo && data.settings.invoiceSettings.logo !== "__local__") {
        try {
          const logoDb = await openLogoIDB();
          await new Promise((res, rej) => {
            const tx = logoDb.transaction("logo", "readwrite");
            tx.objectStore("logo").put(data.settings.invoiceSettings.logo, "current");
            tx.oncomplete = res; tx.onerror = () => rej(tx.error);
          });
          settingsToSave.invoiceSettings.logo = "__local__";
        } catch (_) {}
      }
      await firestoreSetDoc(paths.settingsDoc, settingsToSave, { merge: false });
    }
  }, [paths, db, uid, appSettings, categories]);

  return {
    loading,
    products, alerts, stats, sales, allInvoices, posStats,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    completeSale, recordSale, createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer, receivePayment, addBalanceAdjustment,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
    restoreBackup,
  };
}

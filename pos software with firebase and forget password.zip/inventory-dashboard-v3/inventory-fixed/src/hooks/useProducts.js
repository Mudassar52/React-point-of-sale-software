import { useState, useMemo, useCallback, useEffect, useRef } from "react";
import {
  collection, doc, getDoc, setDoc, addDoc, updateDoc, deleteDoc,
  onSnapshot, query, orderBy
} from "firebase/firestore";
import { PRODUCT_CATEGORIES } from "../data/mockData";
import { buildStockAlerts, getStockStatus } from "../utils/productHelpers";

// ── IndexedDB helpers for logo (same as SettingsView) ────────────────────────
function openLogoIDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open("inv_settings", 1);
    r.onupgradeneeded = (e) => e.target.result.createObjectStore("logo");
    r.onsuccess = (e) => res(e.target.result);
    r.onerror = () => rej(r.error);
  });
}
async function loadLogoFromIDB() {
  try {
    const db = await openLogoIDB();
    return new Promise((res) => {
      const req = db.transaction("logo", "readonly").objectStore("logo").get("current");
      req.onsuccess = () => res(req.result || null);
      req.onerror = () => res(null);
    });
  } catch { return null; }
}

// ── Hook ─────────────────────────────────────────────────────────────────────
export function useProducts(db, uid) {
  const [products, setProducts] = useState([]);
  const [sales, setSales] = useState([]);
  const [manualInvoices, setManualInvoices] = useState([]);
  const [categories, setCategories] = useState(PRODUCT_CATEGORIES);
  const [appSettings, setAppSettings] = useState({ appName: "InvManager", tagline: "Pro Dashboard" });
  const [invoiceSettings, setInvoiceSettings] = useState({ ownerName: "", businessName: "", phone: "", address: "", logo: "" });
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);
  const invoiceCounterRef = useRef(0);

  // ── Firestore paths (per-user) ──────────────────────────────────────────
  const paths = useMemo(() => {
    if (!db || !uid) return null;
    const base = `users/${uid}`;
    return {
      products: collection(db, `${base}/products`),
      sales: collection(db, `${base}/sales`),
      manualInvoices: collection(db, `${base}/manualInvoices`),
      customers: collection(db, `${base}/customers`),
      settingsDoc: doc(db, `${base}/config/settings`),
    };
  }, [db, uid]);

  // ── Bootstrap: seed initial data on first login ─────────────────────────
  useEffect(() => {
    if (!db || !uid || !paths) return;

    async function bootstrap() {
      const settSnap = await getDoc(paths.settingsDoc);
      if (!settSnap.exists()) {
        await setDoc(paths.settingsDoc, {
          appSettings: { appName: "InvManager", tagline: "Pro Dashboard" },
          invoiceSettings: { ownerName: "", businessName: "", phone: "", address: "", logo: "" },
          categories: PRODUCT_CATEGORIES,
          invoiceCounter: 0,
        });
        invoiceCounterRef.current = 0;
      } else {
        invoiceCounterRef.current = settSnap.data().invoiceCounter || 0;
      }
      setLoading(false);
    }

    bootstrap();
  }, [db, uid, paths]);

  // ── Real-time listeners ─────────────────────────────────────────────────
  useEffect(() => {
    if (!paths) return;
    const unsubs = [];

    unsubs.push(
      onSnapshot(paths.products, (snap) => {
        setProducts(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(query(paths.sales, orderBy("createdAt", "desc")), (snap) => {
        setSales(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(query(paths.manualInvoices, orderBy("createdAt", "desc")), (snap) => {
        setManualInvoices(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    unsubs.push(
      onSnapshot(paths.customers, (snap) => {
        setCustomers(snap.docs.map((d) => ({ ...d.data(), id: d.id })));
      })
    );

    // Settings listener
    unsubs.push(
      onSnapshot(paths.settingsDoc, (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          if (data.appSettings) setAppSettings(data.appSettings);
          if (data.invoiceSettings) {
            const settings = data.invoiceSettings;
            // Logo is stored in IndexedDB (too large for Firestore), resolve it
            if (settings.logo === "__local__") {
              loadLogoFromIDB().then((logoData) => {
                setInvoiceSettings({ ...settings, logo: logoData || "" });
              });
            } else {
              setInvoiceSettings(settings);
            }
          }
          if (data.categories) setCategories(data.categories);
        }
      })
    );

    return () => unsubs.forEach((u) => u());
  }, [paths]);

  // ── Computed ────────────────────────────────────────────────────────────
  const alerts = useMemo(() => buildStockAlerts(products), [products]);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, p) => sum + (p.currentStock || 0), 0);
    const lowStockCount = products.filter((p) => getStockStatus(p) === "low").length;
    const outOfStockCount = products.filter((p) => getStockStatus(p) === "out").length;
    return { totalProducts, totalStock, lowStockCount, outOfStockCount };
  }, [products]);

  const allInvoices = useMemo(() => {
    const combined = [
      ...sales.map((s) => ({ ...s, source: s.source || "pos" })),
      ...manualInvoices,
    ];
    return combined.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [sales, manualInvoices]);

  const posStats = useMemo(() => {
    const inStock = products.filter((p) => p.currentStock > 0).length;
    const today = new Date().toDateString();
    const todaySales = sales.filter((s) => new Date(s.createdAt).toDateString() === today);
    const todayRevenue = todaySales.reduce((sum, s) => sum + (s.total || 0), 0);
    return { inStock, todaySalesCount: todaySales.length, todayRevenue };
  }, [products, sales]);

  // ── Product actions ─────────────────────────────────────────────────────
  const addProduct = useCallback(async (form) => {
    if (!paths) return;
    const product = {
      name: form.name.trim(),
      category: form.category,
      salePrice: Number(form.salePrice),
      stockPrice: Number(form.costPrice),
      costPrice: Number(form.costPrice),
      lowStockAlertQty: Number(form.lowStockAlertQty),
      currentStock: Number(form.currentStock) || 0,
    };
    const ref = await addDoc(paths.products, product);
    return { ...product, id: ref.id };
  }, [paths]);

  const updateProduct = useCallback(async (id, form) => {
    if (!paths) return;
    const ref = doc(paths.products, String(id));
    await updateDoc(ref, {
      name: form.name.trim(),
      category: form.category,
      salePrice: Number(form.salePrice),
      stockPrice: Number(form.costPrice),
      costPrice: Number(form.costPrice),
      lowStockAlertQty: Number(form.lowStockAlertQty),
      currentStock: Number(form.currentStock) || 0,
    });
  }, [paths]);

  const deleteProduct = useCallback(async (id) => {
    if (!paths) return;
    await deleteDoc(doc(paths.products, String(id)));
  }, [paths]);

  const stockIn = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0 || !paths) return false;
    const product = products.find((p) => String(p.id) === String(id) || p.id === id);
    if (!product) return false;
    await updateDoc(doc(paths.products, String(id)), {
      currentStock: (product.currentStock || 0) + amount,
    });
    return true;
  }, [paths, products]);

  const stockOut = useCallback(async (id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0 || !paths) return false;
    const product = products.find((p) => String(p.id) === String(id) || p.id === id);
    if (!product || product.currentStock < amount) return false;
    await updateDoc(doc(paths.products, String(id)), {
      currentStock: product.currentStock - amount,
    });
    return true;
  }, [paths, products]);

  const completeSale = useCallback(async (items) => {
    if (!items?.length || !paths) return { success: false };
    // Validate stock first
    for (const { productId, qty } of items) {
      const p = products.find((x) => String(x.id) === String(productId));
      if (!p || (p.currentStock || 0) < qty) return { success: false };
    }
    // Deduct stock in parallel — much faster than sequential awaits
    await Promise.all(items.map(({ productId, qty }) => {
      const p = products.find((x) => String(x.id) === String(productId));
      if (!p) return Promise.resolve();
      return updateDoc(doc(paths.products, String(productId)), {
        currentStock: (p.currentStock || 0) - qty,
      });
    }));
    return { success: true };
  }, [paths, products]);

  const recordSale = useCallback(async (sale) => {
    if (!paths) return;
    // Assign next invoice number from in-memory counter (no Firestore read needed)
    invoiceCounterRef.current += 1;
    const counter = invoiceCounterRef.current;
    setDoc(paths.settingsDoc, { invoiceCounter: counter }, { merge: true }); // fire & forget
    const record = { ...sale, source: "pos", invoiceNumber: counter, createdAt: new Date().toISOString() };
    const ref = await addDoc(paths.sales, record);
    // Update customer stats if a known customer is linked
    if (sale.customerId) {
      const cust = customers.find((c) => String(c.id) === String(sale.customerId));
      if (cust) {
        await updateDoc(doc(paths.customers, String(sale.customerId)), {
          totalOrders: (cust.totalOrders || 0) + 1,
          totalSpent: (cust.totalSpent || 0) + (sale.total || 0),
          lastOrder: new Date().toISOString(),
        });
      }
    }
    return { ...record, id: ref.id };
  }, [paths, customers]);

  // ── Invoice actions ─────────────────────────────────────────────────────
  const createManualInvoice = useCallback(async (data) => {
    if (!paths) return;
    // Assign next invoice number from in-memory counter (no Firestore read needed)
    invoiceCounterRef.current += 1;
    const counter = invoiceCounterRef.current;
    setDoc(paths.settingsDoc, { invoiceCounter: counter }, { merge: true }); // fire & forget
    const record = { ...data, source: "manual", invoiceNumber: counter, createdAt: new Date().toISOString() };
    const ref = await addDoc(paths.manualInvoices, record);
    // Update customer stats if a known customer is linked
    if (data.customerId) {
      const cust = customers.find((c) => String(c.id) === String(data.customerId));
      if (cust) {
        await updateDoc(doc(paths.customers, String(data.customerId)), {
          totalOrders: (cust.totalOrders || 0) + 1,
          totalSpent: (cust.totalSpent || 0) + (data.total || 0),
          lastOrder: new Date().toISOString(),
        });
      }
    }
    return { ...record, id: ref.id };
  }, [paths, customers]);

  const updateInvoice = useCallback(async (id, data, source) => {
    if (!paths) return;
    const colRef = source === "manual" ? paths.manualInvoices : paths.sales;
    await updateDoc(doc(colRef, String(id)), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  }, [paths]);

  const deleteInvoice = useCallback(async (id, source) => {
    if (!paths) return;
    const colRef = source === "manual" ? paths.manualInvoices : paths.sales;
    await deleteDoc(doc(colRef, String(id)));
  }, [paths]);

  // ── Customer actions ────────────────────────────────────────────────────
  const addCustomer = useCallback(async (form) => {
    if (!paths) return;
    const record = {
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email || "",
      city: form.city || "",
      totalOrders: 0,
      totalSpent: 0,
      lastOrder: new Date().toISOString(),
    };
    const ref = await addDoc(paths.customers, record);
    return { ...record, id: ref.id };
  }, [paths]);

  const updateCustomer = useCallback(async (id, form) => {
    if (!paths) return;
    await updateDoc(doc(paths.customers, String(id)), {
      name: form.name.trim(),
      phone: form.phone.trim(),
      email: form.email || "",
      city: form.city || "",
    });
  }, [paths]);

  const deleteCustomer = useCallback(async (id) => {
    if (!paths) return;
    await deleteDoc(doc(paths.customers, String(id)));
  }, [paths]);

  // ── Settings actions ────────────────────────────────────────────────────
  const addCategory = useCallback(async (name) => {
    const trimmed = name.trim();
    if (!trimmed || !paths) return;
    if (categories.includes(trimmed)) return;
    const next = [...categories, trimmed];
    await setDoc(paths.settingsDoc, { categories: next }, { merge: true });
  }, [paths, categories]);

  const removeCategory = useCallback(async (name) => {
    if (!paths) return;
    const next = categories.filter((c) => c !== name);
    await setDoc(paths.settingsDoc, { categories: next }, { merge: true });
  }, [paths, categories]);

  const updateAppSettings = useCallback(async (settings) => {
    if (!paths) return;
    const next = { ...appSettings, ...settings };
    await setDoc(paths.settingsDoc, { appSettings: next }, { merge: true });
  }, [paths, appSettings]);

  const updateInvoiceSettings = useCallback(async (settings) => {
    if (!paths) return;
    const next = { ...invoiceSettings, ...settings };
    await setDoc(paths.settingsDoc, { invoiceSettings: next }, { merge: true });
  }, [paths, invoiceSettings]);

  return {
    loading,
    products, alerts, stats, sales, allInvoices, posStats,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    completeSale, recordSale, createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
  };
}

import { useMemo } from "react";
import StatsGrid from "../common/StatsGrid";
import RevenueChart from "./RevenueChart";
import CategoryPieChart from "./CategoryPieChart";
import ExpensesBarChart from "./ExpensesBarChart";
import TopProductsList from "./TopProductsList";
import { formatCurrency } from "../../utils/productHelpers";

const MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

export default function DashboardView({ products = [], allInvoices = [] }) {
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth();

  /* ── Stats Cards ── */
  const statsCards = useMemo(() => {
    const totalRevenue = allInvoices.reduce((s, i) => s + (i.total || 0), 0);

    const thisMonthRevenue = allInvoices
      .filter(i => { const d = new Date(i.createdAt); return d.getFullYear() === currentYear && d.getMonth() === currentMonth; })
      .reduce((s, i) => s + (i.total || 0), 0);

    const lastMonthRevenue = allInvoices
      .filter(i => {
        const d = new Date(i.createdAt);
        const lm = currentMonth === 0 ? 11 : currentMonth - 1;
        const ly = currentMonth === 0 ? currentYear - 1 : currentYear;
        return d.getFullYear() === ly && d.getMonth() === lm;
      })
      .reduce((s, i) => s + (i.total || 0), 0);

    const revenueChangePct = lastMonthRevenue > 0
      ? ((thisMonthRevenue - lastMonthRevenue) / lastMonthRevenue * 100).toFixed(1)
      : null;

    const todayStr = now.toDateString();
    const todayInvoices = allInvoices.filter(i => new Date(i.createdAt).toDateString() === todayStr);

    return [
      {
        title: "Total Revenue",
        value: formatCurrency(totalRevenue),
        change: revenueChangePct !== null ? `${revenueChangePct > 0 ? "+" : ""}${revenueChangePct}%` : null,
        up: revenueChangePct >= 0,
        icon: "M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z",
        light: "bg-blue-50", text: "text-blue-600",
      },
      {
        title: "This Month Revenue",
        value: formatCurrency(thisMonthRevenue),
        change: null, up: true,
        icon: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6",
        light: "bg-emerald-50", text: "text-emerald-600",
      },
      {
        title: "Total Products",
        value: products.length.toLocaleString(),
        change: null, up: true,
        icon: "M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4",
        light: "bg-violet-50", text: "text-violet-600",
      },
      {
        title: "Total Invoices",
        value: allInvoices.length.toLocaleString(),
        change: todayInvoices.length > 0 ? `+${todayInvoices.length} today` : null,
        up: true,
        icon: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z",
        light: "bg-amber-50", text: "text-amber-600",
      },
    ];
  }, [allInvoices, products, currentYear, currentMonth]);

  /* ── Monthly Revenue Data (current year) ── */
  const monthlyData = useMemo(() => {
    const data = MONTHS.map(m => ({ month: m, revenue: 0, expenses: 0, count: 0 }));
    allInvoices.forEach(inv => {
      const d = new Date(inv.createdAt);
      if (d.getFullYear() === currentYear) {
        const idx = d.getMonth();
        data[idx].revenue += inv.total || 0;
        data[idx].count += 1;
        // Cost estimate from invoice items matched to products
        const cost = (inv.items || []).reduce((s, item) => {
          const prod = products.find(p => p.id === item.productId || p.name === item.name);
          return s + (prod ? prod.costPrice * (item.qty || 0) : (item.lineTotal || 0) * 0.55);
        }, 0);
        data[idx].expenses += cost;
      }
    });
    return data;
  }, [allInvoices, products, currentYear]);

  /* ── Category Pie Data (from real products) ── */
  const categoryData = useMemo(() => {
    const catMap = {};
    products.forEach(p => { catMap[p.category] = (catMap[p.category] || 0) + 1; });
    const total = products.length || 1;
    const colors = ["#1D6FDB","#38BDF8","#0EA5E9","#7DD3FC","#BAE6FD","#34d399","#f59e0b","#a78bfa"];
    return Object.entries(catMap)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count], i) => ({
        name,
        value: Math.round((count / total) * 100),
        color: colors[i % colors.length],
      }));
  }, [products]);

  /* ── Top Products (from invoice items) ── */
  const topProducts = useMemo(() => {
    const map = {};
    allInvoices.forEach(inv => {
      (inv.items || []).forEach(item => {
        const key = item.name;
        if (!map[key]) {
          const prod = products.find(p => p.id === item.productId || p.name === item.name);
          map[key] = { name: item.name, category: prod?.category || "—", stock: prod?.currentStock ?? 0, sold: 0, revenue: 0 };
        }
        map[key].sold += item.qty || 0;
        map[key].revenue += item.lineTotal || 0;
      });
    });
    return Object.values(map)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);
  }, [allInvoices, products]);

  return (
    <div className="flex-1 overflow-y-auto scrollbar-hide px-4 sm:px-6 py-5 space-y-5">
      <StatsGrid cards={statsCards} />

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <RevenueChart data={monthlyData} year={currentYear} />
        <CategoryPieChart data={categoryData} />
      </div>

      <ExpensesBarChart data={monthlyData} />

      <div className="pb-6">
        <TopProductsList data={topProducts} />
      </div>
    </div>
  );
}

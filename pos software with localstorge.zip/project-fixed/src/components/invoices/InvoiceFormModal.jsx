import { useState, useMemo } from "react";
import CustomerSelector from "../common/CustomerSelector";
import { calcTotals } from "../../utils/posHelpers";
import { formatCurrency } from "../../utils/productHelpers";

const emptyItem = () => ({ id: Date.now() + Math.random(), name: "", qty: 1, salePrice: 0, costPrice: 0 });

function prefillItems(existingInvoice) {
  if (!existingInvoice?.items?.length) return [emptyItem()];
  return existingInvoice.items.map((i) => ({
    id: Date.now() + Math.random(),
    name: i.name || "",
    qty: i.qty || 1,
    salePrice: i.unitPrice || i.salePrice || 0,
    costPrice: i.costPrice || 0,
  }));
}

export default function InvoiceFormModal({ products, existingInvoice, onSave, onClose, customers = [] }) {
  const isEdit = !!existingInvoice;
  const [customerName, setCustomerName] = useState(existingInvoice?.customerName || "");
  const [customerPhone, setCustomerPhone] = useState(existingInvoice?.customerPhone || "");
  const [customerAddress, setCustomerAddress] = useState(existingInvoice?.customerAddress || "");
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  const handleCustomerSelect = (c) => {
    setSelectedCustomer(c);
    if (c) {
      setCustomerName(c.name);
      setCustomerPhone(c.phone || "");
      setCustomerAddress(c.city || "");
    } else {
      setCustomerName("");
      setCustomerPhone("");
      setCustomerAddress("");
    }
  };

  const [items, setItems] = useState(() => prefillItems(existingInvoice));
  const [discountPercent, setDiscountPercent] = useState(existingInvoice?.discountPercent ?? 0);
  const [taxPercent, setTaxPercent] = useState(existingInvoice?.taxPercent ?? 0);
  const [notes, setNotes] = useState(existingInvoice?.notes || "");
  const [errors, setErrors] = useState({});

  // Revenue = sum of qty * salePrice
  const subtotal = useMemo(
    () => items.reduce((s, i) => s + Number(i.qty || 0) * Number(i.salePrice || 0), 0),
    [items]
  );
  const { discount, tax, total } = useMemo(
    () => calcTotals(subtotal, Number(discountPercent) || 0, Number(taxPercent) || 0),
    [subtotal, discountPercent, taxPercent]
  );

  // Cost & Profit
  const totalCost = useMemo(
    () => items.reduce((s, i) => s + Number(i.qty || 0) * Number(i.costPrice || 0), 0),
    [items]
  );
  const grossProfit = total - totalCost;
  const profitMargin = total > 0 ? (grossProfit / total) * 100 : 0;

  const addItem = () => setItems((prev) => [...prev, emptyItem()]);
  const removeItem = (id) => setItems((prev) => prev.filter((i) => i.id !== id));
  const updateItem = (id, field, value) =>
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, [field]: value } : i)));

  const fillFromProduct = (id, productId) => {
    const p = products.find((x) => x.id === Number(productId));
    if (!p) return;
    setItems((prev) =>
      prev.map((i) =>
        i.id === id ? { ...i, name: p.name, salePrice: p.salePrice, costPrice: p.costPrice || p.stockPrice || 0 } : i
      )
    );
  };

  const validate = () => {
    const e = {};
    if (!customerName.trim()) e.customerName = "Customer name is required";
    const validItems = items.filter((i) => i.name.trim() && Number(i.qty) > 0 && Number(i.salePrice) >= 0);
    if (validItems.length === 0) e.items = "At least one valid item is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSave = () => {
    if (!validate()) return;
    const validItems = items
      .filter((i) => i.name.trim() && Number(i.qty) > 0)
      .map((i) => ({
        productId: null,
        name: i.name.trim(),
        qty: Number(i.qty),
        unitPrice: Number(i.salePrice),
        salePrice: Number(i.salePrice),
        costPrice: Number(i.costPrice),
        lineTotal: Number(i.qty) * Number(i.salePrice),
        lineCost: Number(i.qty) * Number(i.costPrice),
      }));
    onSave({
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      notes: notes.trim(),
      subtotal, discount, tax,
      discountPercent: Number(discountPercent) || 0,
      taxPercent: Number(taxPercent) || 0,
      total,
      totalCost,
      grossProfit,
      profitMargin: Number(profitMargin.toFixed(2)),
      items: validItems,
      source: "manual",
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className={`w-9 h-9 rounded-xl flex items-center justify-center shadow-md ${isEdit ? "bg-amber-500 shadow-amber-200" : "bg-blue-600 shadow-blue-200"}`}>
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                {isEdit
                  ? <><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" /></>
                  : <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" /><polyline points="14 2 14 8 20 8" /><line x1="12" y1="18" x2="12" y2="12" /><line x1="9" y1="15" x2="15" y2="15" /></>
                }
              </svg>
            </div>
            <div>
              <h2 className="font-bold text-slate-800">{isEdit ? `Edit Invoice #${String(existingInvoice.id).padStart(4, "0")}` : "New Invoice"}</h2>
              <p className="text-xs text-slate-400">{isEdit ? "Save your changes" : "Create a custom invoice"}</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-5">
          {/* Customer */}
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Customer Details</h3>
            {customers.length > 0 && (
              <div className="mb-3">
                <label className="block text-xs font-medium text-slate-600 mb-1.5">Select Saved Customer</label>
                <CustomerSelector customers={customers} onSelect={handleCustomerSelect} selectedCustomer={selectedCustomer} />
                <p className="text-[11px] text-slate-400 mt-1.5">Or fill in details manually below</p>
              </div>
            )}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Customer Name *</label>
                <input value={customerName} onChange={(e) => { setCustomerName(e.target.value); setErrors((p) => ({ ...p, customerName: "" })); }} placeholder="e.g. Ahmad Khan"
                  className={`w-full px-3 py-2.5 rounded-xl border text-sm outline-none transition-colors ${errors.customerName ? "border-red-300 bg-red-50" : "border-slate-200 focus:border-blue-400"}`} />
                {errors.customerName && <p className="text-xs text-red-500 mt-1">{errors.customerName}</p>}
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Phone Number</label>
                <input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="0300-1234567"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-slate-600 mb-1">Address / City</label>
                <input value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)} placeholder="Customer address (optional)"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
              </div>
            </div>
          </div>

          {/* Items */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider">Items</h3>
              <button onClick={addItem} className="flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition-colors">
                <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
                Add Item
              </button>
            </div>
            {errors.items && <p className="text-xs text-red-500 mb-2">{errors.items}</p>}

            {/* Column Headers — desktop only */}
            <div className="hidden sm:grid grid-cols-12 gap-2 px-3 mb-1">
              <div className="col-span-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">Item</div>
              <div className="col-span-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center">Qty</div>
              <div className="col-span-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Sale Price</div>
              <div className="col-span-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Cost Price</div>
              <div className="col-span-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider text-right">Total</div>
            </div>

            <div className="space-y-2">
              {items.map((item) => (
                <div key={item.id} className="bg-slate-50 rounded-xl p-3 border border-slate-100">
                  {/* Product quick-fill */}
                  {products.length > 0 && (
                    <select onChange={(e) => fillFromProduct(item.id, e.target.value)} defaultValue=""
                      className="w-full mb-2 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-xs text-slate-600 outline-none cursor-pointer">
                      <option value="">— Select from product list (auto-fills prices) —</option>
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>{p.name} — Sale: {formatCurrency(p.salePrice)} | Cost: {formatCurrency(p.costPrice || p.stockPrice || 0)}</option>
                      ))}
                    </select>
                  )}

                  {/* Desktop row */}
                  <div className="hidden sm:grid grid-cols-12 gap-2 items-center">
                    <div className="col-span-4">
                      <input value={item.name} onChange={(e) => updateItem(item.id, "name", e.target.value)} placeholder="Item description"
                        className="w-full px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400" />
                    </div>
                    <div className="col-span-2">
                      <input type="number" min="1" value={item.qty} onChange={(e) => updateItem(item.id, "qty", e.target.value)} placeholder="Qty"
                        className="w-full px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400 text-center" />
                    </div>
                    <div className="col-span-2">
                      <input type="number" min="0" value={item.salePrice} onChange={(e) => updateItem(item.id, "salePrice", e.target.value)} placeholder="Sale"
                        className="w-full px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400 text-right" />
                    </div>
                    <div className="col-span-2">
                      <input type="number" min="0" value={item.costPrice} onChange={(e) => updateItem(item.id, "costPrice", e.target.value)} placeholder="Cost"
                        className="w-full px-2.5 py-2 rounded-lg border border-slate-200 bg-amber-50 text-sm outline-none focus:border-amber-400 text-right" />
                    </div>
                    <div className="col-span-2 flex items-center justify-end gap-1">
                      <span className="text-sm font-bold text-blue-600 flex-1 text-right">
                        {formatCurrency(Number(item.qty || 0) * Number(item.salePrice || 0))}
                      </span>
                      {items.length > 1 && (
                        <button onClick={() => removeItem(item.id)} className="w-7 h-7 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors flex-shrink-0">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Mobile layout */}
                  <div className="sm:hidden space-y-2">
                    <div>
                      <label className="text-[10px] font-bold text-slate-400 uppercase">Item</label>
                      <input value={item.name} onChange={(e) => updateItem(item.id, "name", e.target.value)} placeholder="Item description"
                        className="w-full mt-0.5 px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400" />
                    </div>
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Qty</label>
                        <input type="number" min="1" value={item.qty} onChange={(e) => updateItem(item.id, "qty", e.target.value)}
                          className="w-full mt-0.5 px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400 text-center" />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Sale Price</label>
                        <input type="number" min="0" value={item.salePrice} onChange={(e) => updateItem(item.id, "salePrice", e.target.value)}
                          className="w-full mt-0.5 px-2.5 py-2 rounded-lg border border-slate-200 bg-white text-sm outline-none focus:border-blue-400" />
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-amber-500 uppercase">Cost Price</label>
                        <input type="number" min="0" value={item.costPrice} onChange={(e) => updateItem(item.id, "costPrice", e.target.value)}
                          className="w-full mt-0.5 px-2.5 py-2 rounded-lg border border-slate-200 bg-amber-50 text-sm outline-none focus:border-amber-400" />
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-slate-400">
                        Line total: <span className="font-bold text-blue-600">{formatCurrency(Number(item.qty || 0) * Number(item.salePrice || 0))}</span>
                        {item.costPrice > 0 && (
                          <span className="ml-2 text-emerald-600 font-semibold">
                            Profit: {formatCurrency(Number(item.qty || 0) * (Number(item.salePrice || 0) - Number(item.costPrice || 0)))}
                          </span>
                        )}
                      </div>
                      {items.length > 1 && (
                        <button onClick={() => removeItem(item.id)} className="w-7 h-7 flex items-center justify-center text-red-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Discount & Tax */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Discount (%)</label>
              <input type="number" min="0" max="100" value={discountPercent} onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Tax (%)</label>
              <input type="number" min="0" max="100" value={taxPercent} onChange={(e) => setTaxPercent(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-medium text-slate-600 mb-1">Notes</label>
            <textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={2} placeholder="Any special note (optional)..."
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none resize-none" />
          </div>

          {/* Totals */}
          <div className="bg-gradient-to-br from-blue-50 to-slate-50 rounded-2xl p-4 border border-blue-100 space-y-2">
            <div className="flex justify-between text-sm text-slate-600">
              <span>Subtotal</span><span className="font-semibold">{formatCurrency(subtotal)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-sm text-emerald-600">
                <span>Discount ({discountPercent}%)</span><span>-{formatCurrency(discount)}</span>
              </div>
            )}
            {tax > 0 && (
              <div className="flex justify-between text-sm text-slate-600">
                <span>Tax ({taxPercent}%)</span><span>{formatCurrency(tax)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-slate-800 text-base border-t border-blue-100 pt-2 mt-1">
              <span>Total</span>
              <span className="text-blue-600 text-lg">{formatCurrency(total)}</span>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-100 flex gap-3">
          <button onClick={onClose} className="flex-1 py-3 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50">
            Cancel
          </button>
          <button onClick={handleSave}
            className={`flex-1 py-3 rounded-xl text-white text-sm font-bold transition-colors ${isEdit ? "bg-amber-500 hover:bg-amber-600 shadow-md shadow-amber-200" : "bg-blue-600 hover:bg-blue-700 shadow-md shadow-blue-200"}`}>
            {isEdit ? "Save Changes" : "Create Invoice"}
          </button>
        </div>
      </div>
    </div>
  );
}

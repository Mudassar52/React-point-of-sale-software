import { useRef, useState } from "react";
import { formatCurrency } from "../../utils/productHelpers";

function formatDate(iso) {
  return new Date(iso).toLocaleDateString("en-PK", {
    day: "2-digit", month: "short", year: "numeric",
  });
}
function formatTime(iso) {
  return new Date(iso).toLocaleTimeString("en-PK", {
    hour: "2-digit", minute: "2-digit", hour12: true,
  });
}

export default function InvoicePrintModal({ invoice, onClose, invoiceSettings = {} }) {
  const printRef = useRef(null);
  const [isDownloading, setIsDownloading] = useState(false);

  if (!invoice) return null;

  const subtotal = invoice.subtotal || invoice.items?.reduce((s, i) => s + i.lineTotal, 0) || 0;
  const discount = invoice.discount || 0;
  const tax = invoice.tax || 0;
  const total = invoice.total || 0;

  const logoWidth  = invoiceSettings.logoWidth  || 90;
  const logoHeight = invoiceSettings.logoHeight || 56;

  const billedFrom = {
    name: invoiceSettings.ownerName || "",
    business: invoiceSettings.businessName || "",
    phone: invoiceSettings.phone || "",
    address: invoiceSettings.address || "",
    logo: invoiceSettings.logo || "",
  };

  const thankYouMsg = invoiceSettings.thankYouMessage || "Thank you for your business!";
  const displayName = billedFrom.business || billedFrom.name || "My Business";

  /* ─── HTML string for print / download ─── */
  const getInvoiceHTML = () => {
    const logoHtml = billedFrom.logo
      ? `<img src="${billedFrom.logo}" alt="Logo" style="max-width:${logoWidth}px;max-height:${logoHeight}px;width:auto;height:auto;display:block;" />`
      : `<div style="font-size:26px;font-weight:800;color:#0f172a;letter-spacing:-0.5px;line-height:1;">${displayName}</div>`;

    const billedFromHtml = `
      <div style="font-size:14px;color:#0f172a;margin-top:4px;"><span style="font-weight:700;">Business name:</span> ${billedFrom.business || "—"}</div>
      ${billedFrom.name ? `<div style="font-size:14px;color:#0f172a;margin-top:6px;"><span style="font-weight:700;">Owner name:</span> ${billedFrom.name}</div>` : ""}
      ${billedFrom.phone   ? `<div style="font-size:14px;color:#0f172a;margin-top:6px;"><span style="font-weight:700;">Phone:</span> ${billedFrom.phone}</div>`   : ""}
      ${billedFrom.address ? `<div style="font-size:14px;color:#0f172a;margin-top:6px;"><span style="font-weight:700;">Address:</span> ${billedFrom.address}</div>` : ""}
    `;

    const billedToHtml = `
      <div style="font-size:14px;color:#0f172a;margin-top:4px;"><span style="font-weight:700;">Customer name:</span> ${invoice.customerName || "Walk-in Customer"}</div>
      ${invoice.customerPhone   ? `<div style="font-size:14px;color:#0f172a;margin-top:6px;"><span style="font-weight:700;">Phone:</span> ${invoice.customerPhone}</div>`   : ""}
      ${invoice.customerAddress ? `<div style="font-size:14px;color:#0f172a;margin-top:6px;"><span style="font-weight:700;">Address:</span> ${invoice.customerAddress}</div>` : ""}
    `;

    const cellBorder = "border:none;";

    const rowsHtml = invoice.items?.map((item, i) => `
      <tr>
        <td style="padding:13px 15px;font-size:14px;color:#1e293b;text-align:center;${cellBorder}">${i + 1}</td>
        <td style="padding:13px 15px;font-size:14px;font-weight:500;color:#0f172a;${cellBorder}">${item.name}</td>
        <td style="padding:13px 15px;font-size:14px;color:#1e293b;text-align:center;${cellBorder}">${item.qty}</td>
        <td style="padding:13px 15px;font-size:14px;color:#1e293b;text-align:right;${cellBorder}">${formatCurrency(item.unitPrice)}</td>
        <td style="padding:13px 15px;font-size:14px;font-weight:600;color:#0f172a;text-align:right;${cellBorder}">${formatCurrency(item.lineTotal)}</td>
      </tr>
    `).join("") || "";

    return `
      <div style="max-width:760px;margin:0 auto;padding:48px;color:#1e293b;background:#fff;">

        <!-- Header -->
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:36px;border-bottom:1.5px solid #f1f5f9;padding-bottom:28px;">
          <div>
            ${logoHtml}
          </div>
          <div style="text-align:right;">
            <div style="font-size:34px;font-weight:800;color:#2563eb;letter-spacing:-1px;line-height:1;margin-bottom:8px;">INVOICE</div>
            <div style="font-size:14px;color:#475569;">Invoice No. <strong style="color:#0f172a;font-weight:700;">#${String(invoice.id).padStart(4,"0")}</strong></div>
            <div style="font-size:13px;color:#475569;margin-top:5px;">Date: <span style="color:#0f172a;font-weight:600;">${formatDate(invoice.createdAt)}</span></div>
            <div style="font-size:13px;color:#475569;margin-top:4px;">Time: <span style="color:#0f172a;font-weight:600;">${formatTime(invoice.createdAt)}</span></div>
          </div>
        </div>

        <!-- Billed From / Billed To -->
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;margin-bottom:36px;">
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#475569;margin-bottom:8px;">Billed From</div>
            ${billedFromHtml}
          </div>
          <div>
            <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px;color:#475569;margin-bottom:8px;">Billed To</div>
            ${billedToHtml}
          </div>
        </div>

        <!-- Items Table -->
        <table style="width:100%;border-collapse:collapse;margin-bottom:28px;">
          <thead>
            <tr>
              <th style="padding:12px 15px;text-align:center;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#1e40af;width:44px;background:#dbeafe;${cellBorder}">#</th>
              <th style="padding:12px 15px;text-align:left;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#1e40af;background:#dbeafe;${cellBorder}">Item</th>
              <th style="padding:12px 15px;text-align:center;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#1e40af;width:64px;background:#dbeafe;${cellBorder}">Qty</th>
              <th style="padding:12px 15px;text-align:right;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#1e40af;width:110px;background:#dbeafe;${cellBorder}">Unit Price</th>
              <th style="padding:12px 15px;text-align:right;font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:#1e40af;width:120px;background:#dbeafe;${cellBorder}">Total</th>
            </tr>
          </thead>
          <tbody>
            ${rowsHtml}
            <!-- Subtotal Row -->
            <tr style="background:#ffffff;">
              <td colspan="3" style="border:none;"></td>
              <td style="padding:14px 15px 6px;font-size:15px;color:#1e293b;text-align:right;font-weight:700;border-top:1px solid #e2e8f0;">Subtotal</td>
              <td style="padding:14px 15px 6px;font-size:15px;font-weight:700;color:#0f172a;text-align:right;border-top:1px solid #e2e8f0;">${formatCurrency(subtotal)}</td>
            </tr>
            ${discount > 0 ? `
            <tr style="background:#ffffff;">
              <td colspan="3" style="border:none;"></td>
              <td style="padding:5px 15px;font-size:14px;color:#059669;text-align:right;font-weight:500;">Discount (${invoice.discountPercent || 0}%)</td>
              <td style="padding:5px 15px;font-size:14px;font-weight:600;color:#059669;text-align:right;">-${formatCurrency(discount)}</td>
            </tr>
            ` : ""}
            ${tax > 0 ? `
            <tr style="background:#ffffff;">
              <td colspan="3" style="border:none;"></td>
              <td style="padding:5px 15px;font-size:14px;color:#1e293b;text-align:right;font-weight:500;">Tax (${invoice.taxPercent || 0}%)</td>
              <td style="padding:5px 15px;font-size:14px;font-weight:600;color:#0f172a;text-align:right;">${formatCurrency(tax)}</td>
            </tr>
            ` : ""}
            <!-- Total Row -->
            <tr style="background:#ffffff;">
              <td colspan="3" style="border:none;"></td>
              <td style="padding:15px 15px;font-size:15px;color:#0f172a;text-align:right;font-weight:800;border-top:2px solid #cbd5e1;border-bottom:2px solid #cbd5e1;">TOTAL</td>
              <td style="padding:15px 15px;font-size:15px;font-weight:800;color:#0f172a;text-align:right;border-top:2px solid #cbd5e1;border-bottom:2px solid #cbd5e1;">${formatCurrency(total)}</td>
            </tr>
          </tbody>
        </table>

        ${invoice.notes ? `
        <div style="background:#f8fafc;border-radius:6px;padding:18px;border-left:4px solid #94a3b8;margin-bottom:24px;margin-top:16px;">
          <div style="font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:0.5px;color:#64748b;margin-bottom:6px;">Notes</div>
          <div style="font-size:13px;color:#475569;line-height:1.6;">${invoice.notes}</div>
        </div>` : ""}

        <!-- Footer -->
        <div style="text-align:center;padding-top:30px;margin-top:120px;">
          <p style="font-size:12px;color:#0f172a;font-weight:700;margin-bottom:10px;">${thankYouMsg}</p>
          <p style="font-size:11px;color:#0f172a;">Software Design by <strong style="color:#0f172a;font-weight:500;">Mudassar Latif</strong> &nbsp;·&nbsp; 03287458137</p>
        </div>
      </div>
    `;
  };

  const getFullHTML = (title) => `<!DOCTYPE html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/><title>${title}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Inter:wght@400;500;600;700;850&display=swap" rel="stylesheet">
    <style>
      *{margin:0;padding:0;box-sizing:border-box;}
      body{background:#fff;font-family:'Plus Jakarta Sans','Inter',sans-serif;-webkit-print-color-adjust:exact;print-color-adjust:exact;}
      @media print{
        *{-webkit-print-color-adjust:exact;print-color-adjust:exact;}
        @page{size:A4;margin:10mm;}
        body{margin:0;padding:0;}
      }
    </style>
    </head><body>${getInvoiceHTML()}</body></html>`;

  /* ─── PRINT: @media print approach — works on ALL browsers including mobile ─── */
  const handlePrint = () => {
    const invoiceContent = getInvoiceHTML();

    const styleEl = document.createElement("style");
    styleEl.id = "__inv_print_style__";
    styleEl.innerHTML = `
      @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
      @media print {
        #root { display: none !important; visibility: hidden !important; }
        #__inv_print_wrap__ {
          display: block !important;
          visibility: visible !important;
          position: fixed !important;
          inset: 0 !important;
          width: 100% !important;
          background: #fff !important;
          font-family: 'Plus Jakarta Sans', sans-serif !important;
          z-index: 999999 !important;
        }
        @page { size: A4; margin: 10mm; }
        * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
      }
    `;
    document.head.appendChild(styleEl);

    const wrapDiv = document.createElement("div");
    wrapDiv.id = "__inv_print_wrap__";
    wrapDiv.style.cssText = "display:none;";
    wrapDiv.innerHTML = invoiceContent;
    document.body.appendChild(wrapDiv);

    setTimeout(() => { window.print(); }, 400);

    const cleanup = () => {
      const w = document.getElementById("__inv_print_wrap__");
      const s = document.getElementById("__inv_print_style__");
      if (w) document.body.removeChild(w);
      if (s) document.head.removeChild(s);
      window.removeEventListener("afterprint", cleanup);
    };
    window.addEventListener("afterprint", cleanup);
    setTimeout(cleanup, 5000);
  };

  /* ─── DOWNLOAD: Temp div se render karo — overflow-hidden issue fix ─── */
  const handleDownload = async () => {
    if (isDownloading) return;
    setIsDownloading(true);

    try {
      const [{ default: html2canvas }, { jsPDF }] = await Promise.all([
        import("html2canvas"),
        import("jspdf"),
      ]);

      // printRef ki jagah ek fresh temp div use karo — overflow-hidden clipping nahi hogi
      const container = document.createElement("div");
      container.style.position = "fixed";
      container.style.top = "-9999px";
      container.style.left = "-9999px";
      container.style.width = "794px";   // A4 width at 96dpi
      container.style.background = "#ffffff";
      container.style.fontFamily = "'Plus Jakarta Sans', 'Inter', sans-serif";
      container.innerHTML = getInvoiceHTML();
      document.body.appendChild(container);

      // Images load hone ka wait
      await new Promise(r => setTimeout(r, 400));

      const canvas = await html2canvas(container, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: "#ffffff",
        logging: false,
        width: 794,
        windowWidth: 794,
      });

      document.body.removeChild(container);

      const imgData  = canvas.toDataURL("image/png");
      const pdf      = new jsPDF({ unit: "mm", format: "a4", orientation: "portrait" });
      const pageW    = pdf.internal.pageSize.getWidth();   // 210mm
      const pageH    = pdf.internal.pageSize.getHeight();  // 297mm
      const margin   = 8;
      const printW   = pageW - margin * 2;
      const printH   = (canvas.height / canvas.width) * printW;

      if (printH <= pageH - margin * 2) {
        pdf.addImage(imgData, "PNG", margin, margin, printW, printH);
      } else {
        // Multi-page: A4 height chunks mein slice karo
        const pageImgH  = ((pageH - margin * 2) / printW) * canvas.width;
        let srcY        = 0;
        let pageNum     = 0;

        while (srcY < canvas.height) {
          if (pageNum > 0) pdf.addPage();
          const sliceH = Math.min(pageImgH, canvas.height - srcY);
          const sliceCanvas = document.createElement("canvas");
          sliceCanvas.width  = canvas.width;
          sliceCanvas.height = sliceH;
          const ctx = sliceCanvas.getContext("2d");
          ctx.drawImage(canvas, 0, srcY, canvas.width, sliceH, 0, 0, canvas.width, sliceH);
          const sliceData = sliceCanvas.toDataURL("image/png");
          const slicePrintH = (sliceH / canvas.width) * printW;
          pdf.addImage(sliceData, "PNG", margin, margin, printW, slicePrintH);
          srcY += sliceH;
          pageNum++;
        }
      }

      pdf.save(`Invoice-${String(invoice.id).padStart(4, "0")}.pdf`);
    } catch (err) {
      console.error("PDF download error:", err);
    } finally {
      setIsDownloading(false);
    }
  };


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-white rounded-2xl w-full max-w-3xl shadow-2xl flex flex-col max-h-[95vh]">

        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center shadow-md shadow-blue-200">
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
              </svg>
            </div>
            <div>
              <h2 className="font-bold text-slate-800">Invoice #{String(invoice.id).padStart(4,"0")}</h2>
              <p className="text-xs text-slate-400">{formatDate(invoice.createdAt)} · {formatTime(invoice.createdAt)}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              disabled={isDownloading}
              className="flex items-center gap-2 px-4 py-2 text-sm font-bold rounded-xl transition-all"
              style={{
                background: isDownloading
                  ? "linear-gradient(135deg,#374151 0%,#1e3a8a 100%)"
                  : "linear-gradient(135deg,#0f172a 0%,#1e3a8a 100%)",
                color: "#fff",
                boxShadow: "0 4px 14px rgba(30,58,138,0.35)",
                letterSpacing: "0.02em",
                opacity: isDownloading ? 0.75 : 1,
                cursor: isDownloading ? "not-allowed" : "pointer",
              }}
            >
              {isDownloading ? (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ animation: "spin 1s linear infinite" }}>
                    <path d="M21 12a9 9 0 1 1-6.219-8.56"/>
                  </svg>
                  <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
                  Saving...
                </>
              ) : (
                <>
                  <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
                    <polyline points="8 17 12 21 16 17"/><line x1="12" y1="12" x2="12" y2="21"/>
                    <path d="M20.88 18.09A5 5 0 0 0 18 9h-1.26A8 8 0 1 0 3 16.29"/>
                  </svg>
                  Save PDF
                </>
              )}
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-semibold rounded-xl shadow-md shadow-blue-200 transition-colors"
            >
              <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round">
                <polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/><rect x="6" y="14" width="12" height="8"/>
              </svg>
              Print
            </button>
            <button onClick={onClose} className="w-9 h-9 flex items-center justify-center rounded-xl hover:bg-slate-100 text-slate-400 transition-colors">
              <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
          </div>
        </div>

        {/* Invoice Preview */}
        <div className="overflow-y-auto flex-1 p-4 bg-slate-100">
          <div ref={printRef} className="bg-white rounded-2xl shadow-lg max-w-2xl mx-auto overflow-hidden">

            {/* ── HEADER ── */}
            <div className="flex items-start justify-between px-8 pt-8 pb-6 border-b border-slate-100">
              <div>
                {billedFrom.logo ? (
                  <img src={billedFrom.logo} alt="logo" style={{ width: logoWidth, height: logoHeight, objectFit: "contain" }} />
                ) : (
                  <div className="text-2xl font-extrabold text-slate-900 tracking-tight leading-none">{displayName}</div>
                )}
              </div>
              <div className="text-right">
                <h1 className="text-3xl font-extrabold text-blue-600 tracking-tight leading-none">INVOICE</h1>
                <p className="text-sm text-slate-700 mt-2">No. <span className="font-semibold text-slate-900">#{String(invoice.id).padStart(4,"0")}</span></p>
                <p className="text-[13px] text-slate-700 mt-1">Date: <span className="font-medium">{formatDate(invoice.createdAt)}</span></p>
                <p className="text-[13px] text-slate-700 mt-0.5">Time: <span className="font-medium">{formatTime(invoice.createdAt)}</span></p>
              </div>
            </div>

            {/* ── BILLED FROM / TO ── */}
            <div className="grid grid-cols-2 gap-6 px-8 py-6">
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">Billed From</p>
                <p className="text-sm text-slate-900 mt-1"><span className="font-bold">Business name:</span> {billedFrom.business || "—"}</p>
                {billedFrom.name && <p className="text-sm text-slate-900 mt-1.5"><span className="font-bold">Owner name:</span> {billedFrom.name}</p>}
                {billedFrom.phone && <p className="text-sm text-slate-900 mt-1.5"><span className="font-bold">Phone:</span> {billedFrom.phone}</p>}
                {billedFrom.address && <p className="text-sm text-slate-900 mt-1"><span className="font-bold">Address:</span> {billedFrom.address}</p>}
              </div>
              <div>
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-500 mb-2">Billed To</p>
                <p className="text-sm text-slate-900 mt-1"><span className="font-bold">Customer name:</span> {invoice.customerName || "Walk-in Customer"}</p>
                {invoice.customerPhone && <p className="text-sm text-slate-900 mt-1.5"><span className="font-bold">Phone:</span> {invoice.customerPhone}</p>}
                {invoice.customerAddress && <p className="text-sm text-slate-900 mt-1"><span className="font-bold">Address:</span> {invoice.customerAddress}</p>}
              </div>
            </div>

            {/* ── ITEMS TABLE ── */}
            <div className="px-8 pb-2">
              <table className="w-full text-slate-700" style={{ borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th className="px-3 py-3 text-center w-10" style={{ fontSize: "10px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", color: "#1e40af", background: "#dbeafe" }}>#</th>
                    <th className="px-4 py-3 text-left" style={{ fontSize: "10px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", color: "#1e40af", background: "#dbeafe" }}>Item</th>
                    <th className="px-4 py-3 text-center w-12" style={{ fontSize: "10px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", color: "#1e40af", background: "#dbeafe" }}>Qty</th>
                    <th className="px-4 py-3 text-right w-24" style={{ fontSize: "10px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", color: "#1e40af", background: "#dbeafe" }}>Unit Price</th>
                    <th className="px-4 py-3 text-right w-28" style={{ fontSize: "10px", fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px", color: "#1e40af", background: "#dbeafe" }}>Total</th>
                  </tr>
                </thead>
                <tbody>
                  {invoice.items?.map((item, idx) => (
                    <tr key={idx}>
                      <td className="px-3 py-4 text-sm text-slate-700 text-center font-medium">{idx + 1}</td>
                      <td className="px-4 py-4 text-sm text-slate-900 font-medium">{item.name}</td>
                      <td className="px-4 py-4 text-sm text-slate-800 text-center">{item.qty}</td>
                      <td className="px-4 py-4 text-sm text-slate-800 text-right">{formatCurrency(item.unitPrice)}</td>
                      <td className="px-4 py-4 text-sm font-semibold text-slate-900 text-right">{formatCurrency(item.lineTotal)}</td>
                    </tr>
                  ))}

                  <tr className="bg-white">
                    <td colSpan={3} className="border-0 py-0"></td>
                    <td className="px-4 py-3.5 text-[15px] font-bold text-slate-800 text-right border-t border-slate-200">Subtotal</td>
                    <td className="px-4 py-3.5 text-[15px] font-bold text-slate-900 text-right border-t border-slate-200">{formatCurrency(subtotal)}</td>
                  </tr>

                  {discount > 0 && (
                    <tr className="bg-white">
                      <td colSpan={3} className="border-0 py-0"></td>
                      <td className="px-4 py-2 text-sm font-medium text-emerald-600 text-right">Discount ({invoice.discountPercent || 0}%)</td>
                      <td className="px-4 py-2 text-sm font-bold text-emerald-600 text-right">-{formatCurrency(discount)}</td>
                    </tr>
                  )}

                  {tax > 0 && (
                    <tr className="bg-white">
                      <td colSpan={3} className="border-0 py-0"></td>
                      <td className="px-4 py-2 text-sm font-medium text-slate-800 text-right">Tax ({invoice.taxPercent || 0}%)</td>
                      <td className="px-4 py-2 text-sm font-semibold text-slate-900 text-right">{formatCurrency(tax)}</td>
                    </tr>
                  )}

                  <tr className="bg-white">
                    <td colSpan={3} className="border-0 py-0"></td>
                    <td className="px-4 py-4 font-extrabold text-slate-900 text-right border-t-2 border-slate-400" style={{ fontSize: "15px" }}>TOTAL</td>
                    <td className="px-4 py-4 font-extrabold text-slate-900 text-right border-t-2 border-slate-400" style={{ fontSize: "15px" }}>{formatCurrency(total)}</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {invoice.notes && (
              <div className="mx-8 mb-5 bg-slate-50 rounded-xl p-4 border-l-4 border-slate-400 mt-4">
                <p className="text-[11px] font-bold uppercase tracking-wider text-slate-600 mb-1.5">Notes</p>
                <p className="text-sm text-slate-800 leading-relaxed">{invoice.notes}</p>
              </div>
            )}

            {/* ── FOOTER ── */}
            <div className="text-center px-8 py-10 mt-24">
              <p className="text-xs font-bold text-slate-900">{thankYouMsg}</p>
              <p className="text-xs text-slate-900 mt-2">
                Software Design by <span className="font-medium text-slate-900">Mudassar Latif</span>
                &nbsp;·&nbsp; 03287458137
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

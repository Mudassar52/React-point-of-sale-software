import { useState, useMemo } from "react";
import CustomerSelector from "../common/CustomerSelector";
import { formatCurrency } from "../../utils/productHelpers";
import { calcTotals } from "../../utils/posHelpers";
import ProductIcon from "../common/ProductIcon";

export default function POSCheckoutModal({ cartItems, products, onConfirm, onClose, customers = [] }) {
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [customerAddress, setCustomerAddress] = useState("");
  const [selectedCustomer, setSelectedCustomer] = useState(null);

  const handleCustomerSelect = (c) => {
    setSelectedCustomer(c);
    if (c) {
      setCustomerName(c.name);
      setCustomerPhone(c.phone || "");
      setCustomerAddress(c.city || "");
    } else {
      setCustomerName("");
      setCustomerPhone("");
      setCustomerAddress("");
    }
  };
  const [discountPercent, setDiscountPercent] = useState(0);
  const [taxPercent, setTaxPercent] = useState(0);
  const [localCart, setLocalCart] = useState(cartItems);
  const [errors, setErrors] = useState({});

  const subtotal = useMemo(
    () => localCart.reduce((s, item) => s + item.product.salePrice * item.qty, 0),
    [localCart]
  );
  const { discount, tax, total } = useMemo(
    () => calcTotals(subtotal, Number(discountPercent) || 0, Number(taxPercent) || 0),
    [subtotal, discountPercent, taxPercent]
  );

  const updateQty = (productId, delta) => {
    const product = products.find((p) => p.id === productId);
    if (!product) return;
    setLocalCart((prev) =>
      prev
        .map((c) => {
          if (c.productId !== productId) return c;
          const newQty = c.qty + delta;
          if (newQty <= 0) return null;
          if (newQty > product.currentStock) return c;
          return { ...c, qty: newQty };
        })
        .filter(Boolean)
    );
  };

  const removeItem = (productId) =>
    setLocalCart((prev) => prev.filter((c) => c.productId !== productId));

  const validate = () => {
    const e = {};
    if (!customerName.trim()) e.customerName = "Customer ka naam likhein";
    if (localCart.length === 0) e.cart = "Cart khali hai";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (!validate()) return;
    onConfirm({
      localCart,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      customerAddress: customerAddress.trim(),
      subtotal,
      discount,
      tax,
      discountPercent: Number(discountPercent) || 0,
      taxPercent: Number(taxPercent) || 0,
      total,
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-t-3xl sm:rounded-2xl w-full sm:max-w-lg shadow-2xl flex flex-col max-h-[95vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center shadow-md shadow-blue-200">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2" />
                <circle cx="9" cy="7" r="4" />
                <path d="M23 21v-2a4 4 0 0 0-3-3.87" />
                <path d="M16 3.13a4 4 0 0 1 0 7.75" />
              </svg>
            </div>
            <div>
              <h2 className="font-bold text-slate-800">Customer Details</h2>
              <p className="text-xs text-slate-400">Complete invoice</p>
            </div>
          </div>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-slate-100 text-slate-400">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
              <path d="M18 6L6 18M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto flex-1 px-5 py-4 space-y-5">
          {/* Cart Summary */}
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Cart Summary</h3>
            {errors.cart && <p className="text-xs text-red-500 mb-2">{errors.cart}</p>}
            <div className="space-y-2">
              {localCart.map((item) => (
                <div key={item.productId} className="flex items-center gap-3 bg-slate-50 rounded-xl p-3 border border-slate-100">
                  <div className="w-9 h-9 rounded-lg bg-white border border-slate-100 flex items-center justify-center flex-shrink-0">
                    <ProductIcon size={14} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-slate-800 truncate">{item.product.name}</p>
                    <p className="text-xs text-slate-400">{formatCurrency(item.product.salePrice)} each · {item.product.currentStock} in stock</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <button onClick={() => updateQty(item.productId, -1)} className="w-7 h-7 rounded-lg bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M5 12h14" /></svg>
                    </button>
                    <input
                      type="number"
                      min="1"
                      max={item.product.currentStock}
                      value={item.qty}
                      onChange={(e) => {
                        const val = parseInt(e.target.value, 10);
                        if (!isNaN(val) && val >= 1 && val <= item.product.currentStock) {
                          setLocalCart(prev => prev.map(c => c.productId === item.productId ? { ...c, qty: val } : c));
                        }
                      }}
                      className="w-12 text-center text-sm font-bold text-slate-800 border border-slate-200 rounded-lg outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 py-0.5 bg-white"
                    />
                    <button onClick={() => updateQty(item.productId, 1)} disabled={item.qty >= item.product.currentStock} className="w-7 h-7 rounded-lg bg-white border border-slate-200 flex items-center justify-center hover:bg-slate-100 disabled:opacity-40 transition-colors">
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>
                    </button>
                    <button onClick={() => removeItem(item.productId)} className="w-7 h-7 rounded-lg bg-red-50 text-red-500 flex items-center justify-center hover:bg-red-100 transition-colors ml-1">
                      <svg xmlns="http://www.w3.org/2000/svg" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12" /></svg>
                    </button>
                  </div>
                  <span className="text-sm font-black text-blue-600 min-w-[4rem] text-right flex-shrink-0">
                    {formatCurrency(item.product.salePrice * item.qty)}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Discount & Tax */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Discount (%)</label>
              <input type="number" min="0" max="100" value={discountPercent} onChange={(e) => setDiscountPercent(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
            </div>
            <div>
              <label className="block text-xs font-medium text-slate-600 mb-1">Tax (%)</label>
              <input type="number" min="0" max="100" value={taxPercent} onChange={(e) => setTaxPercent(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
            </div>
          </div>

          {/* Totals */}
          <div className="bg-gradient-to-br from-blue-50 to-slate-50 rounded-2xl p-4 border border-blue-100 space-y-1.5">
            <div className="flex justify-between text-sm text-slate-600">
              <span>Subtotal</span><span className="font-semibold">{formatCurrency(subtotal)}</span>
            </div>
            {discount > 0 && (
              <div className="flex justify-between text-sm text-emerald-600">
                <span>Discount ({discountPercent}%)</span><span>-{formatCurrency(discount)}</span>
              </div>
            )}
            {tax > 0 && (
              <div className="flex justify-between text-sm text-slate-600">
                <span>Tax ({taxPercent}%)</span><span>{formatCurrency(tax)}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-slate-800 text-base border-t border-blue-100 pt-2 mt-1">
              <span>Total</span>
              <span className="text-blue-600 text-lg font-black">{formatCurrency(total)}</span>
            </div>
          </div>

          {/* Customer Info */}
          <div>
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">Customer Details</h3>
            <div className="space-y-3">
              {/* Select from saved customers */}
              {customers.length > 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-600 mb-1.5">Select Saved Customer</label>
                  <CustomerSelector customers={customers} onSelect={handleCustomerSelect} selectedCustomer={selectedCustomer} />
                  <p className="text-[11px] text-slate-400 mt-1.5">Or fill in details manually below</p>
                </div>
              )}
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Customer Name *</label>
                <input
                  value={customerName}
                  onChange={(e) => { setCustomerName(e.target.value); setErrors((p) => ({ ...p, customerName: "" })); }}
                  placeholder="e.g. Ahmad Khan"
                  className={`w-full px-3 py-2.5 rounded-xl border text-sm outline-none transition-colors ${errors.customerName ? "border-red-300 bg-red-50" : "border-slate-200 focus:border-blue-400"}`}
                />
                {errors.customerName && <p className="text-xs text-red-500 mt-1">{errors.customerName}</p>}
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Phone Number</label>
                <input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="0300-1234567"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 mb-1">Address / City</label>
                <input value={customerAddress} onChange={(e) => setCustomerAddress(e.target.value)} placeholder="Customer address (optional)"
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-blue-400 text-sm outline-none" />
              </div>
            </div>
          </div>
        </div>

        {/* Footer Buttons */}
        <div className="px-5 py-4 border-t border-slate-100 flex gap-3 flex-shrink-0">
          <button onClick={onClose} className="flex-1 py-3.5 rounded-2xl border border-slate-200 text-sm font-bold text-slate-600 hover:bg-slate-50">
            Back
          </button>
          <button onClick={handleSubmit} disabled={localCart.length === 0}
            className="flex-1 py-3.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-bold shadow-lg shadow-emerald-200 transition-all active:scale-[0.99] flex items-center justify-center gap-2">
            <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
            Generate Invoice
          </button>
        </div>
      </div>
    </div>
  );
}

import { formatCurrency } from "../../utils/productHelpers";
import { formatSaleTime } from "../../utils/posHelpers";

export default function POSReceiptModal({ sale, onClose, onNewSale }) {
  if (!sale) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 px-6 py-8 text-center text-white">
          <div className="w-14 h-14 mx-auto mb-3 rounded-full bg-white/20 flex items-center justify-center">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M20 6L9 17l-5-5" />
            </svg>
          </div>
          <h2 className="text-xl font-bold">Sale Complete</h2>
          <p className="text-emerald-100 text-sm mt-1">Order #{sale.id} · {formatSaleTime(sale.createdAt)}</p>
        </div>

        <div className="px-6 py-5 max-h-[50vh] overflow-y-auto scrollbar-hide">
          {sale.customerName && (
            <p className="text-sm text-slate-500 mb-3">
              Customer: <span className="font-semibold text-slate-800">{sale.customerName}</span>
            </p>
          )}

          <div className="space-y-2 mb-4">
            {sale.items.map((item) => (
              <div key={item.productId} className="flex justify-between text-sm gap-3">
                <span className="text-slate-700 flex-1 min-w-0 truncate">
                  {item.name} <span className="text-slate-400">×{item.qty}</span>
                </span>
                <span className="font-medium text-slate-800 flex-shrink-0">{formatCurrency(item.lineTotal)}</span>
              </div>
            ))}
          </div>

          <div className="border-t border-slate-100 pt-3">
            <div className="flex justify-between font-bold text-slate-800 text-base">
              <span>Total</span>
              <span className="text-blue-600">{formatCurrency(sale.total)}</span>
            </div>
          </div>
        </div>

        <div className="px-6 pb-6 flex gap-3">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50"
          >
            Close
          </button>
          <button
            type="button"
            onClick={onNewSale}
            className="flex-1 py-2.5 rounded-xl bg-blue-600 text-white text-sm font-medium hover:bg-blue-700 shadow-md shadow-blue-200"
          >
            New Sale
          </button>
        </div>
      </div>
    </div>
  );
}

import { useState, useMemo, useCallback } from "react";
import { initialProducts, initialCustomers, PRODUCT_CATEGORIES } from "../data/mockData";
import { buildStockAlerts, getStockStatus } from "../utils/productHelpers";
import { calcTotals } from "../utils/posHelpers";

let nextId = 7;
let nextSaleId = 1;
let nextCustomerId = 100;

function loadCustomers() {
  try { return JSON.parse(localStorage.getItem("inv-customers") || "null") || initialCustomers; } catch { return initialCustomers; }
}
function loadCategories() {
  try { return JSON.parse(localStorage.getItem("inv-categories") || "null") || PRODUCT_CATEGORIES; } catch { return PRODUCT_CATEGORIES; }
}
function loadAppSettings() {
  try { return JSON.parse(localStorage.getItem("inv-app-settings") || "null") || { appName: "InvManager", tagline: "Pro Dashboard" }; } catch { return { appName: "InvManager", tagline: "Pro Dashboard" }; }
}
function loadInvoiceSettings() {
  try { return JSON.parse(localStorage.getItem("inv-invoice-settings") || "null") || { ownerName: "", businessName: "", phone: "", address: "", logo: "" }; } catch { return { ownerName: "", businessName: "", phone: "", address: "", logo: "" }; }
}
function loadSales() {
  try { return JSON.parse(localStorage.getItem("inv-sales") || "[]"); } catch { return []; }
}
function loadManualInvoices() {
  try { return JSON.parse(localStorage.getItem("inv-manual-invoices") || "[]"); } catch { return []; }
}
function getNextId(sales, manual) {
  const max = [...sales, ...manual].reduce((m, s) => Math.max(m, s.id || 0), 0);
  return max + 1;
}

export function useProducts() {
  const [products, setProducts] = useState(initialProducts);
  const [sales, setSales] = useState(() => {
    const s = loadSales(); nextSaleId = getNextId(s, loadManualInvoices()); return s;
  });
  const [manualInvoices, setManualInvoices] = useState(loadManualInvoices);
  const [categories, setCategories] = useState(loadCategories);
  const [appSettings, setAppSettings] = useState(loadAppSettings);
  const [invoiceSettings, setInvoiceSettings] = useState(loadInvoiceSettings);

  const [customers, setCustomers] = useState(() => {
    const c = loadCustomers();
    nextCustomerId = c.reduce((m, x) => Math.max(m, x.id || 0), 99) + 1;
    return c;
  });

  const alerts = useMemo(() => buildStockAlerts(products), [products]);

  const stats = useMemo(() => {
    const totalProducts = products.length;
    const totalStock = products.reduce((sum, p) => sum + p.currentStock, 0);
    const lowStockCount = products.filter((p) => getStockStatus(p) === "low").length;
    const outOfStockCount = products.filter((p) => getStockStatus(p) === "out").length;
    return { totalProducts, totalStock, lowStockCount, outOfStockCount };
  }, [products]);

  const addProduct = useCallback((form) => {
    const product = { id: nextId++, name: form.name.trim(), category: form.category, salePrice: Number(form.salePrice), stockPrice: Number(form.costPrice), costPrice: Number(form.costPrice), lowStockAlertQty: Number(form.lowStockAlertQty), currentStock: Number(form.currentStock) || 0 };
    setProducts((prev) => [...prev, product]);
    return product;
  }, []);

  const updateProduct = useCallback((id, form) => {
    setProducts((prev) => prev.map((p) => p.id === id ? { ...p, name: form.name.trim(), category: form.category, salePrice: Number(form.salePrice), stockPrice: Number(form.costPrice), costPrice: Number(form.costPrice), lowStockAlertQty: Number(form.lowStockAlertQty), currentStock: Number(form.currentStock) || 0 } : p));
  }, []);

  const deleteProduct = useCallback((id) => { setProducts((prev) => prev.filter((p) => p.id !== id)); }, []);

  const stockIn = useCallback((id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0) return false;
    setProducts((prev) => prev.map((p) => p.id === id ? { ...p, currentStock: p.currentStock + amount } : p));
    return true;
  }, []);

  const stockOut = useCallback((id, qty) => {
    const amount = Number(qty);
    if (!amount || amount <= 0) return false;
    let success = false;
    setProducts((prev) => {
      const product = prev.find((p) => p.id === id);
      if (!product || product.currentStock < amount) return prev;
      success = true;
      return prev.map((p) => p.id === id ? { ...p, currentStock: p.currentStock - amount } : p);
    });
    return success;
  }, []);

  const completeSale = useCallback((items) => {
    if (!items?.length) return { success: false };
    let success = false;
    setProducts((prev) => {
      const next = [...prev];
      for (const { productId, qty } of items) {
        const idx = next.findIndex((p) => p.id === productId);
        if (idx === -1 || next[idx].currentStock < qty) return prev;
      }
      for (const { productId, qty } of items) {
        const idx = next.findIndex((p) => p.id === productId);
        next[idx] = { ...next[idx], currentStock: next[idx].currentStock - qty };
      }
      success = true;
      return next;
    });
    return { success };
  }, []);

  const recordSale = useCallback((sale) => {
    const record = { ...sale, id: nextSaleId++, source: "pos", createdAt: new Date().toISOString() };
    setSales((prev) => {
      const next = [record, ...prev].slice(0, 100);
      localStorage.setItem("inv-sales", JSON.stringify(next));
      return next;
    });
    return record;
  }, []);

  const createManualInvoice = useCallback((data) => {
    const record = { ...data, id: nextSaleId++, source: "manual", createdAt: new Date().toISOString() };
    setManualInvoices((prev) => {
      const next = [record, ...prev].slice(0, 500);
      localStorage.setItem("inv-manual-invoices", JSON.stringify(next));
      return next;
    });
    return record;
  }, []);

  const updateInvoice = useCallback((id, data, source) => {
    if (source === "manual") {
      setManualInvoices((prev) => {
        const next = prev.map((inv) => inv.id === id ? { ...inv, ...data, id, source: "manual", updatedAt: new Date().toISOString() } : inv);
        localStorage.setItem("inv-manual-invoices", JSON.stringify(next));
        return next;
      });
    } else {
      // POS sales bhi edit ho sakti hain
      setSales((prev) => {
        const next = prev.map((inv) => inv.id === id ? { ...inv, ...data, id, source: "pos", updatedAt: new Date().toISOString() } : inv);
        localStorage.setItem("inv-sales", JSON.stringify(next));
        return next;
      });
    }
  }, []);

  const deleteInvoice = useCallback((id, source) => {
    if (source === "manual") {
      setManualInvoices((prev) => {
        const next = prev.filter((inv) => inv.id !== id);
        localStorage.setItem("inv-manual-invoices", JSON.stringify(next));
        return next;
      });
    } else {
      setSales((prev) => {
        const next = prev.filter((inv) => inv.id !== id);
        localStorage.setItem("inv-sales", JSON.stringify(next));
        return next;
      });
    }
  }, []);

  const allInvoices = useMemo(() => {
    const combined = [
      ...sales.map((s) => ({ ...s, source: s.source || "pos" })),
      ...manualInvoices,
    ];
    return combined.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }, [sales, manualInvoices]);

  const posStats = useMemo(() => {
    const inStock = products.filter((p) => p.currentStock > 0).length;
    const today = new Date().toDateString();
    const todaySales = sales.filter((s) => new Date(s.createdAt).toDateString() === today);
    const todayRevenue = todaySales.reduce((sum, s) => sum + s.total, 0);
    return { inStock, todaySalesCount: todaySales.length, todayRevenue };
  }, [products, sales]);

  const addCategory = useCallback((name) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    setCategories((prev) => {
      if (prev.includes(trimmed)) return prev;
      const next = [...prev, trimmed];
      localStorage.setItem("inv-categories", JSON.stringify(next));
      return next;
    });
  }, []);

  const removeCategory = useCallback((name) => {
    setCategories((prev) => {
      const next = prev.filter((c) => c !== name);
      localStorage.setItem("inv-categories", JSON.stringify(next));
      return next;
    });
  }, []);

  const updateAppSettings = useCallback((settings) => {
    setAppSettings((prev) => {
      const next = { ...prev, ...settings };
      localStorage.setItem("inv-app-settings", JSON.stringify(next));
      return next;
    });
  }, []);

  const updateInvoiceSettings = useCallback((settings) => {
    setInvoiceSettings((prev) => {
      const next = { ...prev, ...settings };
      localStorage.setItem("inv-invoice-settings", JSON.stringify(next));
      return next;
    });
  }, []);

  const addCustomer = useCallback((form) => {
    const record = { id: nextCustomerId++, name: form.name.trim(), phone: form.phone.trim(), email: form.email || "", city: form.city || "", totalOrders: 0, totalSpent: 0, lastOrder: new Date().toISOString() };
    setCustomers((prev) => {
      const next = [...prev, record];
      localStorage.setItem("inv-customers", JSON.stringify(next));
      return next;
    });
    return record;
  }, []);

  const updateCustomer = useCallback((id, form) => {
    setCustomers((prev) => {
      const next = prev.map((c) => c.id === id ? { ...c, name: form.name.trim(), phone: form.phone.trim(), email: form.email || "", city: form.city || "" } : c);
      localStorage.setItem("inv-customers", JSON.stringify(next));
      return next;
    });
  }, []);

  const deleteCustomer = useCallback((id) => {
    setCustomers((prev) => {
      const next = prev.filter((c) => c.id !== id);
      localStorage.setItem("inv-customers", JSON.stringify(next));
      return next;
    });
  }, []);

  return {
    products, alerts, stats, sales, allInvoices, posStats,
    addProduct, updateProduct, deleteProduct, stockIn, stockOut,
    completeSale, recordSale, createManualInvoice, updateInvoice, deleteInvoice,
    customers, addCustomer, updateCustomer, deleteCustomer,
    categories, addCategory, removeCategory,
    appSettings, updateAppSettings,
    invoiceSettings, updateInvoiceSettings,
  };
}
